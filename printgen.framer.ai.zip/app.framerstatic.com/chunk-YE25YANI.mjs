async function s(t,n){let e=await(await fetch(t)).blob();return new File([e],n,{type:e.type})}export{s as a};
//# sourceMappingURL=https://app.framerstatic.com/chunk-YE25YANI.mjs.map
