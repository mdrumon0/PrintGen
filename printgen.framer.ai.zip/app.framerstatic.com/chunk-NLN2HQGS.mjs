import{xd as o}from"https://app.framerstatic.com/chunk-QRJ4RQFN.mjs";function d(t,n){let e=t.getNode(n.webPageId);return o(e)?e:null}export{d as a};
//# sourceMappingURL=https://app.framerstatic.com/chunk-NLN2HQGS.mjs.map
