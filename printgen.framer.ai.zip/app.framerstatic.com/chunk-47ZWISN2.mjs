import{b as t}from"https://app.framerstatic.com/chunk-YTGAT6FQ.mjs";import{o as r}from"https://app.framerstatic.com/chunk-IZV4HDYJ.mjs";function n(){return t.isOn("crdt")}function s(){return r.isDevelopment||r.isLocal}function i(){return!1}export{n as a,s as b,i as c};
//# sourceMappingURL=https://app.framerstatic.com/chunk-47ZWISN2.mjs.map
