import{b as e,c as n}from"https://app.framerstatic.com/chunk-RGU2JJBI.mjs";var r=new n("sandbox",{sandbox:new e,controlsVisibility:new e,modulesRuntime:new e,componentsStore:new e,sandboxStore:new e,treeStore:new e});export{r as a};
//# sourceMappingURL=https://app.framerstatic.com/chunk-7HL2QOVD.mjs.map
