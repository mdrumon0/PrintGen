import{b as r}from"https://app.framerstatic.com/chunk-4T36ZEA6.mjs";r();
//# sourceMappingURL=https://app.framerstatic.com/chunk-YSBEIMRL.mjs.map
