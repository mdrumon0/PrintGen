import{j as e,k as t}from"https://app.framerstatic.com/chunk-GVWL364Z.mjs";var o={kit:"off",sites:"on",skipInterstitial:"off",crdt:"off",canvasPages:"off"},r=new e(o,{assertIfUsedBeforeUpdate:!0});typeof window<"u"&&window.framerProjectFeatures&&r.update(window.framerProjectFeatures);var s=t(r);export{o as a,r as b};
//# sourceMappingURL=https://app.framerstatic.com/chunk-YTGAT6FQ.mjs.map
