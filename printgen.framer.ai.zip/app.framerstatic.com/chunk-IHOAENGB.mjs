import{b as t}from"https://app.framerstatic.com/chunk-WNSBRACC.mjs";function s(e){switch(e){case 2:case 5:case 6:case 4:return!0;case 0:case 1:case 3:return!1;default:t(e)}}export{s as a};
//# sourceMappingURL=https://app.framerstatic.com/chunk-IHOAENGB.mjs.map
