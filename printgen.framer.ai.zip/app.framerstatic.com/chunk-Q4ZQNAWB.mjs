var n=window.location;function t(o){n.href=o}export{t as a};
//# sourceMappingURL=https://app.framerstatic.com/chunk-Q4ZQNAWB.mjs.map
