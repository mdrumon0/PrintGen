import{a as e}from"https://app.framerstatic.com/chunk-BWUNBOFS.mjs";import{e as u}from"https://app.framerstatic.com/chunk-AHQIRSXG.mjs";var r=u(e());function l(t){let n=(0,r.useRef)(null);return n.current===null&&(n.current=t()),n.current}export{l as a};
//# sourceMappingURL=https://app.framerstatic.com/chunk-6OD3X52Q.mjs.map
