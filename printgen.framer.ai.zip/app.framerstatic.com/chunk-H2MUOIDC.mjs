import{a as u}from"https://app.framerstatic.com/chunk-BWUNBOFS.mjs";import{e as n}from"https://app.framerstatic.com/chunk-AHQIRSXG.mjs";var e=n(u());function l(r){let t=(0,e.useRef)(r);return t.current=r,(0,e.useCallback)((...s)=>t.current(...s),[])}export{l as a};
//# sourceMappingURL=https://app.framerstatic.com/chunk-H2MUOIDC.mjs.map
