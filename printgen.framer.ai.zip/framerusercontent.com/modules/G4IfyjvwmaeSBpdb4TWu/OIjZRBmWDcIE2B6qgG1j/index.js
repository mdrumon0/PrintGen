import {
  defaultEvents,
  localeOptions,
  fontControls,
  fontSizeOptions,
  emptyStateStyle,
  containerStyles,
  fontStack,
} from "https://framerusercontent.com/modules/VTUDdizacRHpwbkOamr7/AykinQJbgwl92LvMGZwu/constants.js";
import {
  useOnEnter,
  useOnExit,
} from "https://framerusercontent.com/modules/D4TWeLfcxT6Tysr2BlYg/iZjmqdxVx1EOiM3k1FaW/useOnNavigationTargetChange.js";
import { useConstant } from "https://framerusercontent.com/modules/ExNgrA7EJTKUPpH6vIlN/eiOrSJ2Ab5M9jPCvVwUz/useConstant.js";
import {
  colorTokentoValue,
  colorFromToken,
} from "https://framerusercontent.com/modules/D2Lz5CmnNVPZFFiZXalt/QaCzPbriZBfXWZIIycFI/colorFromToken.js";
import { isMotionValue } from "https://framerusercontent.com/modules/3mKFSGQqKHV82uOV1eBc/5fbRLvOpxZC0JOXugvwm/isMotionValue.js";
import {
  useUniqueClassName,
  randomID,
} from "https://framerusercontent.com/modules/xDiQsqBGXzmMsv7AlEVy/uhunpMiNsbXxzjlXsg1y/useUniqueClassName.js";
import { getVariantControls } from "https://framerusercontent.com/modules/ETACN5BJyFTSo0VVDJfu/NHRqowOiXkF9UwOzczF7/variantUtils.js";
import { useIsBrowserSafari } from "https://framerusercontent.com/modules/eMBrwoqQK7h6mEeGQUH8/GuplvPJVjmxpk9zqOTcb/isBrowser.js";
import {
  useMultiOnChange,
  useOnChange,
} from "https://framerusercontent.com/modules/v9AWX2URmiYsHf7GbctE/XxKAZ9KlhWqf5x1JMyyF/useOnChange.js";
import {
  mstoMinAndSec,
  secondsToMinutes,
} from "https://framerusercontent.com/modules/4zHZnO5JojN1PrIbu2jm/revv9QCWpkh8lPzi2jje/time.js";
import { useAutoMotionValue } from "https://framerusercontent.com/modules/kNDwabfjDEb3vUxkQlZS/fSIr3AOAYbGlfSPgXpYu/useAutoMotionValue.js";
import { useFontControls } from "https://framerusercontent.com/modules/cuQH4dmpDnV8YK1mSgQX/KqRXqunFjE6ufhpc7ZRu/useFontControls.js";
import {
  useRenderTarget,
  useIsInPreview,
  useIsOnCanvas,
} from "https://framerusercontent.com/modules/afBE9Yx1W6bY5q32qPxe/m3q7puE2tbo1S2C0s0CT/useRenderTarget.js";
import { useControlledState } from "https://framerusercontent.com/modules/zGkoP8tPDCkoBzMdt5uq/0zFSjxIYliHxrQQnryFX/useControlledState.js";
import {
  usePadding,
  useRadius,
  paddingControl,
  borderRadiusControl,
} from "https://framerusercontent.com/modules/5SM58HxZHxjjv7aLMOgQ/WXz9i6mVki0bBCrKdqB3/propUtils.js";
import { detectAutoSizingAxis } from "https://framerusercontent.com/modules/8CkHAZatUz1UR8jNTcfD/HwbnIAZlUmQ2oTpcLkaH/detectAutoSizingAxis.js";
export {
  useOnEnter,
  useOnExit,
  defaultEvents,
  isMotionValue,
  colorFromToken,
  colorTokentoValue,
  localeOptions,
  fontControls,
  fontSizeOptions,
  emptyStateStyle,
  containerStyles,
  fontStack,
  useUniqueClassName,
  getVariantControls,
  useIsBrowserSafari,
  randomID,
  useConstant,
  useMultiOnChange,
  useOnChange,
  usePadding,
  useRadius,
  paddingControl,
  borderRadiusControl,
  mstoMinAndSec,
  useFontControls,
  secondsToMinutes,
  useAutoMotionValue,
  useRenderTarget,
  useIsInPreview,
  useControlledState,
  detectAutoSizingAxis,
  useIsOnCanvas,
};
export const __FramerMetadata__ = {
  exports: {
    useConstant: {
      type: "variable",
      annotations: { framerContractVersion: "1" },
    },
    isMotionValue: {
      type: "variable",
      annotations: { framerContractVersion: "1" },
    },
    fontControls: {
      type: "variable",
      annotations: { framerContractVersion: "1" },
    },
    defaultEvents: {
      type: "variable",
      annotations: { framerContractVersion: "1" },
    },
    useUniqueClassName: {
      type: "variable",
      annotations: { framerContractVersion: "1" },
    },
    useMultiOnChange: {
      type: "variable",
      annotations: { framerContractVersion: "1" },
    },
    useOnChange: {
      type: "variable",
      annotations: { framerContractVersion: "1" },
    },
    useIsOnCanvas: {
      type: "variable",
      annotations: { framerContractVersion: "1" },
    },
    useOnExit: {
      type: "variable",
      annotations: { framerContractVersion: "1" },
    },
    fontSizeOptions: {
      type: "variable",
      annotations: { framerContractVersion: "1" },
    },
    colorTokentoValue: {
      type: "variable",
      annotations: { framerContractVersion: "1" },
    },
    useRadius: {
      type: "variable",
      annotations: { framerContractVersion: "1" },
    },
    getVariantControls: {
      type: "variable",
      annotations: { framerContractVersion: "1" },
    },
    colorFromToken: {
      type: "variable",
      annotations: { framerContractVersion: "1" },
    },
    containerStyles: {
      type: "variable",
      annotations: { framerContractVersion: "1" },
    },
    usePadding: {
      type: "variable",
      annotations: { framerContractVersion: "1" },
    },
    fontStack: {
      type: "variable",
      annotations: { framerContractVersion: "1" },
    },
    useControlledState: {
      type: "variable",
      annotations: { framerContractVersion: "1" },
    },
    useFontControls: {
      type: "variable",
      annotations: { framerContractVersion: "1" },
    },
    useAutoMotionValue: {
      type: "variable",
      annotations: { framerContractVersion: "1" },
    },
    emptyStateStyle: {
      type: "variable",
      annotations: { framerContractVersion: "1" },
    },
    useIsInPreview: {
      type: "variable",
      annotations: { framerContractVersion: "1" },
    },
    useIsBrowserSafari: {
      type: "variable",
      annotations: { framerContractVersion: "1" },
    },
    detectAutoSizingAxis: {
      type: "variable",
      annotations: { framerContractVersion: "1" },
    },
    borderRadiusControl: {
      type: "variable",
      annotations: { framerContractVersion: "1" },
    },
    mstoMinAndSec: {
      type: "variable",
      annotations: { framerContractVersion: "1" },
    },
    randomID: { type: "variable", annotations: { framerContractVersion: "1" } },
    localeOptions: {
      type: "variable",
      annotations: { framerContractVersion: "1" },
    },
    useOnEnter: {
      type: "variable",
      annotations: { framerContractVersion: "1" },
    },
    secondsToMinutes: {
      type: "variable",
      annotations: { framerContractVersion: "1" },
    },
    useRenderTarget: {
      type: "variable",
      annotations: { framerContractVersion: "1" },
    },
    paddingControl: {
      type: "variable",
      annotations: { framerContractVersion: "1" },
    },
  },
};
