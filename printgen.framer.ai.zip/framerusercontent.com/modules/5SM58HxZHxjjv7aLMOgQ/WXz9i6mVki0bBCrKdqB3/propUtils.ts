import { useMemo } from "react"
import { ControlType, PropertyControls } from "framer"

/**
 * Helpers for Props
 */

export interface RadiusProps {
    borderRadius: number
    isMixedBorderRadius: boolean
    topLeftRadius: number
    topRightRadius: number
    bottomRightRadius: number
    bottomLeftRadius: number
}

export function useRadius(props) {
    const {
        borderRadius,
        isMixedBorderRadius,
        topLeftRadius,
        topRightRadius,
        bottomRightRadius,
        bottomLeftRadius,
    } = props

    const radiusValue = useMemo(
        () =>
            isMixedBorderRadius
                ? `${topLeftRadius}px ${topRightRadius}px ${bottomRightRadius}px ${bottomLeftRadius}px`
                : `${borderRadius}px`,
        [
            borderRadius,
            isMixedBorderRadius,
            topLeftRadius,
            topRightRadius,
            bottomRightRadius,
            bottomLeftRadius,
        ]
    )

    return radiusValue
}

export const borderRadiusControl: PropertyControls = {
    borderRadius: {
        title: "Radius",
        type: ControlType.FusedNumber,
        toggleKey: "isMixedBorderRadius",
        toggleTitles: ["Radius", "Radius per corner"],
        valueKeys: [
            "topLeftRadius",
            "topRightRadius",
            "bottomRightRadius",
            "bottomLeftRadius",
        ],
        valueLabels: ["TL", "TR", "BR", "BL"],
        min: 0,
    },
}

export interface PaddingProps {
    padding: number
    paddingPerSide: true
    paddingTop: number
    paddingRight: number
    paddingBottom: number
    paddingLeft: number
}

export function usePadding(props: PaddingProps) {
    const {
        padding,
        paddingPerSide,
        paddingTop,
        paddingRight,
        paddingBottom,
        paddingLeft,
    } = props

    const paddingValue = useMemo(
        () =>
            paddingPerSide
                ? `${paddingTop}px ${paddingRight}px ${paddingBottom}px ${paddingLeft}px`
                : padding,
        [
            padding,
            paddingPerSide,
            paddingTop,
            paddingRight,
            paddingBottom,
            paddingLeft,
        ]
    )

    return paddingValue
}

export const paddingControl: PropertyControls = {
    padding: {
        type: ControlType.FusedNumber,
        toggleKey: "paddingPerSide",
        toggleTitles: ["Padding", "Padding per side"],
        valueKeys: [
            "paddingTop",
            "paddingRight",
            "paddingBottom",
            "paddingLeft",
        ],
        valueLabels: ["T", "R", "B", "L"],
        min: 0,
        title: "Padding",
    },
}
