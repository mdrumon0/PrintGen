export const { Fragment, jsx, jsxs, jsxDEV } = window.__REACT_RUNTIME_JSX__;
