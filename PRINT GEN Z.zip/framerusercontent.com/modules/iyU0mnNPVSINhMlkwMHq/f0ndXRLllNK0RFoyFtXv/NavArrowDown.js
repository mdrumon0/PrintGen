let o;
var w = (r) => {
  if (!o) {
    let e = function (n, t) {
      return r.createElement(
        "svg",
        {
          width: "100%",
          height: "1.5em",
          strokeWidth: 1.5,
          viewBox: "0 0 24 24",
          fill: "none",
          xmlns: "http://www.w3.org/2000/svg",
          color: "currentColor",
          ref: t,
          ...n,
        },
        r.createElement("path", {
          d: "M6 9l6 6 6-6",
          stroke: "currentColor",
          strokeLinecap: "round",
          strokeLinejoin: "round",
        })
      );
    };
    o = r.forwardRef(e);
  }
  return o;
};
export { w as default };
