import * as React from "react"
import { useMemo } from "react"
import { addPropertyControls, ControlType } from "framer"
import { motion } from "framer-motion"
import { containerStyles } from "https://framer.com/m/framer/default-utils.js@^0.45.0"
import {
    emptyStateStyle,
    stateParagraphStyle,
    stateTitleStyle,
} from "https://framer.com/m/framer/integrations-styles.js@0.2.0"

const facebookRegex = /^https?:\/\/(?:www\.)?facebook\.com\//

/**
 * Facebook
 *
 * @framerIntrinsicWidth 200
 * @framerIntrinsicHeight 200
 *
 * @framerSupportedLayoutWidth any
 * @framerSupportedLayoutHeight any
 */
export default function Facebook({ url, style, ...props }) {
    const encodedUrl = useMemo(() => {
        if (!facebookRegex.test(url)) {
            return null
        }

        return encodeURIComponent(url.replace(/(\?.*)/, ""))
    }, [url])

    return url && encodedUrl ? (
        <motion.iframe
            style={{ ...containerStyles, ...style }}
            src={`https://www.facebook.com/plugins/post.php?href=${encodedUrl}`}
            frameBorder={0}
            width="100%"
            height="100%"
            scrolling="no"
            {...props}
        />
    ) : (
        <motion.div
            style={{
                ...emptyStateStyle,
                ...style,
            }}
            {...props}
        >
            <h1 style={stateTitleStyle}>Facebook</h1>
            {url ? (
                <p style={stateParagraphStyle}>
                    This post URL doesn’t seem correct.
                </p>
            ) : (
                <p style={stateParagraphStyle}>
                    Set a post URL in the Properties.
                </p>
            )}
        </motion.div>
    )
}

addPropertyControls(Facebook, {
    url: {
        title: "URL",
        type: ControlType.String,
        placeholder: "https://www.facebook.com/***",
        defaultValue:
            "https://www.facebook.com/framerjs/videos/284888495883514",
    },
})
