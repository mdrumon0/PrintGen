import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
import { useMemo } from "react";
import { addPropertyControls, ControlType } from "framer";
import { motion } from "framer-motion";
import { containerStyles } from "https://framer.com/m/framer/default-utils.js@^0.45.0";
import {
  emptyStateStyle,
  stateParagraphStyle,
  stateTitleStyle,
} from "https://framer.com/m/framer/integrations-styles.js@0.2.0";
const facebookRegex = /^https?:\/\/(?:www\.)?facebook\.com\//;
/**
 * Facebook
 *
 * @framerIntrinsicWidth 200
 * @framerIntrinsicHeight 200
 *
 * @framerSupportedLayoutWidth any
 * @framerSupportedLayoutHeight any
 */ export default function Facebook({ url, style, ...props }) {
  const encodedUrl = useMemo(() => {
    if (!facebookRegex.test(url)) {
      return null;
    }
    return encodeURIComponent(url.replace(/(\?.*)/, ""));
  }, [url]);
  return url && encodedUrl
    ? /*#__PURE__*/ _jsx(motion.iframe, {
        style: { ...containerStyles, ...style },
        src: `https://www.facebook.com/plugins/post.php?href=${encodedUrl}`,
        frameBorder: 0,
        width: "100%",
        height: "100%",
        scrolling: "no",
        ...props,
      })
    : /*#__PURE__*/ _jsxs(motion.div, {
        style: { ...emptyStateStyle, ...style },
        ...props,
        children: [
          /*#__PURE__*/ _jsx("h1", {
            style: stateTitleStyle,
            children: "Facebook",
          }),
          url
            ? /*#__PURE__*/ _jsx("p", {
                style: stateParagraphStyle,
                children: "This post URL doesn’t seem correct.",
              })
            : /*#__PURE__*/ _jsx("p", {
                style: stateParagraphStyle,
                children: "Set a post URL in the Properties.",
              }),
        ],
      });
}
addPropertyControls(Facebook, {
  url: {
    title: "URL",
    type: ControlType.String,
    placeholder: "https://www.facebook.com/***",
    defaultValue: "https://www.facebook.com/framerjs/videos/284888495883514",
  },
});
export const __FramerMetadata__ = {
  exports: {
    default: {
      type: "reactComponent",
      name: "Facebook",
      slots: [],
      annotations: {
        framerSupportedLayoutWidth: "any",
        framerIntrinsicWidth: "200",
        framerSupportedLayoutHeight: "any",
        framerContractVersion: "1",
        framerIntrinsicHeight: "200",
      },
    },
    __FramerMetadata__: { type: "variable" },
  },
};
//# sourceMappingURL=./Facebook.map
