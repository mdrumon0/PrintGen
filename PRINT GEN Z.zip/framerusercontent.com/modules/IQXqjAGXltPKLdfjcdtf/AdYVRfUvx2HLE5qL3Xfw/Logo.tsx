import { useMemo } from "react"
import { addPropertyControls, ControlType, RenderTarget } from "framer"
import { NullState } from "https://framer.com/m/framer/icon-nullstate.js@0.7.0"

enum SrcType {
    Upload = "Upload",
    Url = "URL",
}

interface Props {
    company?: string
    radius: number
    isSearch?: boolean
    srcType?: SrcType
    srcUrl?: string
    srcFile?: string
}

interface State {
    company: string
    radius: number
}

const baseUrl = "https://logo.clearbit.com/"
const getLogoUrl = (company) => {
    if (!company) return null
    return company.includes(".")
        ? `${baseUrl}${company}?size=500`
        : `${baseUrl}${company}.com?size=500`
}

/**
 * @framerIntrinsicWidth 64
 * @framerIntrinsicHeight 64
 *
 * @framerSupportedLayoutWidth fixed
 * @framerSupportedLayoutHeight fixed
 */
export default function Logo(props: Props) {
    const { company, radius, isSearch, srcType, srcUrl, srcFile, style } = props

    const logoURL = useMemo(() => {
        if (isSearch) return getLogoUrl(company)
        if (srcType === SrcType.Upload) return srcFile
        if (srcType === SrcType.Url) return srcUrl
        return null
    }, [company, isSearch, srcType, srcUrl, srcFile])

    const isOnCanvas = RenderTarget.current() === RenderTarget.canvas
    const emptyState = isOnCanvas ? <NullState /> : null

    return logoURL ? (
        <img
            src={logoURL}
            style={{ ...baseStyles, ...style, borderRadius: radius }}
            alt={"Logo"}
        />
    ) : (
        emptyState
    )
}

Logo.defaultProps = {
    company: "Framer",
    radius: 100,
    width: 64,
    height: 64,
    isSearch: true,
}

const baseStyles: React.CSSProperties = {
    position: "absolute",
    left: 0,
    right: 0,
    top: 0,
    bottom: 0,
    width: "100%",
    height: "100%",
}

addPropertyControls(Logo, {
    isSearch: {
        type: ControlType.Boolean,
        title: "Type",
        disabledTitle: "Custom",
        enabledTitle: "Search",
    },
    srcType: {
        type: ControlType.Enum,
        displaySegmentedControl: true,
        title: "Source",
        options: [SrcType.Url, SrcType.Upload],
        hidden: ({ isSearch }) => isSearch,
    },
    srcUrl: {
        type: ControlType.String,
        title: " ",
        placeholder: "../example.jpg",
        hidden: ({ srcType, isSearch }) =>
            srcType === SrcType.Upload || isSearch,
    },
    srcFile: {
        type: ControlType.File,
        title: " ",
        allowedFileTypes: ["jpg", "png", "jpeg", "tiff", "gif"],
        hidden: ({ srcType, isSearch }) => srcType === SrcType.Url || isSearch,
    },
    company: {
        type: ControlType.String,
        title: "Company",
        placeholder: "Github, Apple...",

        hidden: ({ isSearch }) => !isSearch,
    },
    radius: { type: ControlType.Number, min: 0, max: 100, title: "Radius" },
})
