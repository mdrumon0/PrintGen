import { jsx as _jsx } from "react/jsx-runtime";
import { useMemo } from "react";
import { addPropertyControls, ControlType, RenderTarget } from "framer";
import { NullState } from "https://framer.com/m/framer/icon-nullstate.js@0.7.0";
var SrcType;
(function (SrcType) {
  SrcType["Upload"] = "Upload";
  SrcType["Url"] = "URL";
})(SrcType || (SrcType = {}));
const baseUrl = "https://logo.clearbit.com/";
const getLogoUrl = (company) => {
  if (!company) return null;
  return company.includes(".")
    ? `${baseUrl}${company}?size=500`
    : `${baseUrl}${company}.com?size=500`;
};
/**
 * @framerIntrinsicWidth 64
 * @framerIntrinsicHeight 64
 *
 * @framerSupportedLayoutWidth fixed
 * @framerSupportedLayoutHeight fixed
 */ export default function Logo(props) {
  const { company, radius, isSearch, srcType, srcUrl, srcFile, style } = props;
  const logoURL = useMemo(() => {
    if (isSearch) return getLogoUrl(company);
    if (srcType === SrcType.Upload) return srcFile;
    if (srcType === SrcType.Url) return srcUrl;
    return null;
  }, [company, isSearch, srcType, srcUrl, srcFile]);
  const isOnCanvas = RenderTarget.current() === RenderTarget.canvas;
  const emptyState = isOnCanvas ? /*#__PURE__*/ _jsx(NullState, {}) : null;
  return logoURL
    ? /*#__PURE__*/ _jsx("img", {
        src: logoURL,
        style: { ...baseStyles, ...style, borderRadius: radius },
        alt: "Logo",
      })
    : emptyState;
}
Logo.defaultProps = {
  company: "Framer",
  radius: 100,
  width: 64,
  height: 64,
  isSearch: true,
};
const baseStyles = {
  position: "absolute",
  left: 0,
  right: 0,
  top: 0,
  bottom: 0,
  width: "100%",
  height: "100%",
};
addPropertyControls(Logo, {
  isSearch: {
    type: ControlType.Boolean,
    title: "Type",
    disabledTitle: "Custom",
    enabledTitle: "Search",
  },
  srcType: {
    type: ControlType.Enum,
    displaySegmentedControl: true,
    title: "Source",
    options: [SrcType.Url, SrcType.Upload],
    hidden: ({ isSearch }) => isSearch,
  },
  srcUrl: {
    type: ControlType.String,
    title: " ",
    placeholder: "../example.jpg",
    hidden: ({ srcType, isSearch }) => srcType === SrcType.Upload || isSearch,
  },
  srcFile: {
    type: ControlType.File,
    title: " ",
    allowedFileTypes: ["jpg", "png", "jpeg", "tiff", "gif"],
    hidden: ({ srcType, isSearch }) => srcType === SrcType.Url || isSearch,
  },
  company: {
    type: ControlType.String,
    title: "Company",
    placeholder: "Github, Apple...",
    hidden: ({ isSearch }) => !isSearch,
  },
  radius: { type: ControlType.Number, min: 0, max: 100, title: "Radius" },
});
export const __FramerMetadata__ = {
  exports: {
    default: {
      type: "reactComponent",
      name: "Logo",
      slots: [],
      annotations: {
        framerSupportedLayoutWidth: "fixed",
        framerSupportedLayoutHeight: "fixed",
        framerContractVersion: "1",
        framerIntrinsicWidth: "64",
        framerIntrinsicHeight: "64",
      },
    },
    __FramerMetadata__: { type: "variable" },
  },
};
//# sourceMappingURL=./Logo.map
