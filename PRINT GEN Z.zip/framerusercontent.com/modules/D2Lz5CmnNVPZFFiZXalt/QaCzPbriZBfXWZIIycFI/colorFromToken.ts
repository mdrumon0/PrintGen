import { Color } from "framer"

export function colorFromToken(color: string) {
    if (color.startsWith("var(--token-"))
        return "rgb" + color.split(") /*")[0].split(", rgb")[1]

    return color
}

export function colorTokentoValue(color: string): string {
    return Color(colorFromToken(color)).toValue()
}
