let e;
var f = (r) => {
  if (!e) {
    let o = function (t, n) {
      return r.createElement(
        "svg",
        {
          width: "100%",
          height: "1.5em",
          strokeWidth: 1.5,
          viewBox: "0 0 24 24",
          fill: "none",
          xmlns: "http://www.w3.org/2000/svg",
          color: "currentColor",
          ref: n,
          ...t,
        },
        r.createElement("path", {
          d: "M3 9.5L12 4l9 5.5M19 13v6.4a.6.6 0 01-.6.6H5.6a.6.6 0 01-.6-.6V13",
          stroke: "currentColor",
          strokeLinecap: "round",
          strokeLinejoin: "round",
        })
      );
    };
    e = r.forwardRef(o);
  }
  return e;
};
export { f as default };
