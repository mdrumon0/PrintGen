import {
    containerStyles,
    emptyStateStyle as defaultEmptyStateStyle,
} from "https://framer.com/m/framer/default-utils.js@^0.43.0"
import { CSSProperties } from "react"

export const emptyStateStyle: CSSProperties = {
    ...containerStyles,
    ...defaultEmptyStateStyle,
    textAlign: "center",
    padding: 15,
    width: 200,
    height: 100,
    overflow: "hidden",
}

export const neutralStateStyle: CSSProperties = {
    ...emptyStateStyle,
    color: "#09f",
    background: "rgb(0, 153, 255, 0.1)",
    borderColor: "#09f",
}

export const stateTitleStyle: CSSProperties = {
    fontSize: 12,
    fontWeight: 600,
    margin: 0,
}

export const stateParagraphStyle: CSSProperties = {
    fontSize: 12,
    maxWidth: 200,
    lineHeight: 1.4,
    margin: "5px 0 0 0",
}
