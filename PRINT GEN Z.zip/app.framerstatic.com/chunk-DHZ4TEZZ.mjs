import{b as e,c as n}from"https://app.framerstatic.com/chunk-XBN5SXSF.mjs";var r=new n("sandbox",{sandbox:new e,controlsVisibility:new e,modulesRuntime:new e,componentsStore:new e,sandboxStore:new e,treeStore:new e});export{r as a};
//# sourceMappingURL=https://app.framerstatic.com/chunk-DHZ4TEZZ.mjs.map
