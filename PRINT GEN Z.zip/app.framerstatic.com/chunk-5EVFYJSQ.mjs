import{a as i}from"https://app.framerstatic.com/chunk-LQILWJHN.mjs";function t(e){return!e?.endsWith(i().previewDomain)}export{t as a};
//# sourceMappingURL=https://app.framerstatic.com/chunk-5EVFYJSQ.mjs.map
