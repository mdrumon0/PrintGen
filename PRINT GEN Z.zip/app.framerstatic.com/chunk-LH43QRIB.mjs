function o(n,r,t){return`${n.toLocaleString()} ${n===1?r:t}`}export{o as a};
//# sourceMappingURL=https://app.framerstatic.com/chunk-LH43QRIB.mjs.map
