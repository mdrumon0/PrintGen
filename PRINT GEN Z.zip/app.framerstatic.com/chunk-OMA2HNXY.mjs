import{a as e}from"https://app.framerstatic.com/chunk-IE6AATEJ.mjs";function o(){return e("(prefers-color-scheme: dark)")}export{o as a};
//# sourceMappingURL=https://app.framerstatic.com/chunk-OMA2HNXY.mjs.map
