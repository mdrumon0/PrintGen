function n(t){return t.id}export{n as a};
//# sourceMappingURL=https://app.framerstatic.com/chunk-PABHF7FN.mjs.map
