import{b as r}from"https://app.framerstatic.com/chunk-AO4UNU73.mjs";r();
//# sourceMappingURL=https://app.framerstatic.com/chunk-ENNJHVQF.mjs.map
