var i=(n,m,t)=>{let r=Math.min(m,t),c=Math.max(m,t);return n<r&&(n=r),n>c&&(n=c),n};export{i as a};
//# sourceMappingURL=https://app.framerstatic.com/chunk-VXJAAVJQ.mjs.map
