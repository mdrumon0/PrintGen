import{a as o}from"https://app.framerstatic.com/chunk-SVKHBLAX.mjs";import{a as t}from"https://app.framerstatic.com/chunk-BWUNBOFS.mjs";import{e as r}from"https://app.framerstatic.com/chunk-AHQIRSXG.mjs";var e=r(t());function a(){return(0,e.useContext)(o)}export{a};
//# sourceMappingURL=https://app.framerstatic.com/chunk-OBSLC4FZ.mjs.map
