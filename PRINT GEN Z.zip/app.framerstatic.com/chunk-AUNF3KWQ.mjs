var t=[];function i(e){return t.push(e),function(){t=t.filter(n=>e!==n)}}function o(e,r){t.forEach(n=>n(e,r))}export{i as a,o as b};
//# sourceMappingURL=https://app.framerstatic.com/chunk-AUNF3KWQ.mjs.map
