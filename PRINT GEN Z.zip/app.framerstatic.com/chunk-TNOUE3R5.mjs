import{xd as o}from"https://app.framerstatic.com/chunk-TMEDOQFH.mjs";function d(t,n){let e=t.getNode(n.webPageId);return o(e)?e:null}export{d as a};
//# sourceMappingURL=https://app.framerstatic.com/chunk-TNOUE3R5.mjs.map
